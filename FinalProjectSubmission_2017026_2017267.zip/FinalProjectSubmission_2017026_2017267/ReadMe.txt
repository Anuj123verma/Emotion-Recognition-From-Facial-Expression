THe final code is in SML_Project-ipynb and .py
The real time prediction code is in Real_Time.py 
The Segmentation of images is in code Segmentation_Images.py 

The model links are in given word file named Model_links

2017267_mod11.sav - Model trained from given images
2017267_hist11.sav - History of Model trained from given images

2017267_mod12.sav - Model trained from images with added noise
2017267_hist12.sav - History of Model trained from images with added noise

2017267_mod13.sav - Model trained from images predicted with conv AE. 
2017267_hist13.sav - History of Model trained from images predicted with conv AE.

2017267_mod14.sav - Model trained from segmented images
2017267_hist14.sav - History of Model trained from segmented images

