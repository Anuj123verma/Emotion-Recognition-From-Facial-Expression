#!/usr/bin/env python
# coding: utf-8

# # Import Libraries

# In[109]:


import cv2
import pickle
import numpy as np
import matplotlib.pyplot as plt


# # Load CNN Model which we trained

# In[110]:


emotions = {0:"Angry", 1:"Disgust", 2:"Fear", 3:"Happy", 4:"Sad", 5:"Surprise", 6:"Neutral"}
file= "C:\\Users\\Sohaib Fazal\\Downloads\\2017267_mod12.sav"
model = pickle.load(open(file,'rb'))


# In[111]:


FACE_CLASSIFIER = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_frontalface_default.xml')


# THE PREDICTION IS RETURNED AFTER READING THE IMAGE PATH

# In[112]:


def return_prediction(image_path):
    
    ####The image read is converted to grayscale
    ####The image is read from the path and is resized to (48,48) for fitting to CNN
    #### The image is predicted by checking th maximum probability among the classes. 
    
    img = cv2.imread(image_path)
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    cv2.imwrite(image_path, gray)
    
    
    img = cv2.imread(image_path)
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    faces = FACE_CLASSIFIER.detectMultiScale(gray, 1.5, 1)
    
    for (x,y,w,h) in faces:
        face_clip = img[y:y+h, x:x+w]
        imj = cv2.resize(face_clip,(48,48))
        cv2.imwrite(image_path, imj)
    
    read_image = cv2.imread(image_path,0)

    print(read_image.shape)
    read_image = cv2.resize(read_image,(48,48))
    read_image = read_image.reshape(read_image.shape[0], read_image.shape[1],1)
    
    X_test_im =[]
    X_test_im.append(read_image)
    X_test_im = np.array(X_test_im)
    X_test_im = X_test_im.reshape((1,48,48,1))
    
    predicted_classes = model.predict_classes(X_test_im)
    print(predicted_classes[0])
    emotion_label = predicted_classes[0]
    return emotions[emotion_label]


# # Function calling the prediction function

# In[113]:


cam = cv2.VideoCapture(0)

def func(text, cam):
    
    ### Press 1 to quit reading 
    ### Press space for Taking the picture
    
    while(True):
        ret, img = cam.read()
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        font = cv2.FONT_HERSHEY_COMPLEX
        cv2.putText(img, "Last Emotion was "+str(text), (50,50), font, 1.0, (0,255 , 0), 1)
        
        
        faces = FACE_CLASSIFIER.detectMultiScale(gray, 1.3, 3)
        for x,y,w,h in faces:
            cv2.rectangle(img, (x,y), (x+w, y+h), (255, 0, 0), 2)
        
        cv2.imshow("Image", img)
        
        
        if cv2.waitKey(1) == ord(' '):
            cv2.imwrite("test.jpg", img) 
            text = return_prediction("test.jpg")
            func(text, cam)
            break
            
        if cv2.waitKey(1) == ord('1'):
            cam.release()
            cv2.destroyAllWindows()
            break


# In[114]:


FACE_CLASSIFIER


# In[115]:


func('None',cam)

